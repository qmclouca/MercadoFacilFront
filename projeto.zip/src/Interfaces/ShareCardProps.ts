export interface ShareCardProps {
    logoUrl: string,
    longName: string,
    symbol: string,
    regularMarketPrice: string | number,
}