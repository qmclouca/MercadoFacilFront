export interface UserAddress {
    userId: string,
    addressId: string
}